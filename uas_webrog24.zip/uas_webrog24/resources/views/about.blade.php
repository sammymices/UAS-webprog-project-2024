<div class="col-12 text-center">
    <h2>About Us</h2>
    <span class="sub-title">Sejarah, Struktur, dan Visi Misi Yayasan Al-Mubarok</span>
</div>