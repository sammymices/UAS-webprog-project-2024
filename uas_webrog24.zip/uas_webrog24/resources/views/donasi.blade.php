<div class="col-12 text-center">
    <h2>Donasi</h2>
    <span class="sub-title">Donasi Anda, Harapan Mereka</span>
</div>